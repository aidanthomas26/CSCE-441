Aidan Thomas 
332003177
athomas26@tamu.edu
Completed all tasks
Used ChatGPT for supplemental help.


