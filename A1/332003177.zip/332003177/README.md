Aidan Thomas 
332003177
athomas26@tamu.edu
Completed all tasks
Used ChatGPT for barycentric equations

There are still some bugs with the colouring and the z buffer but I spent so much time on this assignment I have to just call it there because I have other things to do.
